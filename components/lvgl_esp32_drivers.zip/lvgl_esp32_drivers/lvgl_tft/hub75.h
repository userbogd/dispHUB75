 /* 
  Copyright 2022 Bogdan Pilyugin
 
  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at
 
     http://www.apache.org/licenses/LICENSE-2.0
 
  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 
    File name: hub75.h
      Project: dispHUB75
   Created on: 2022-07-18
       Author: Bogdan Pilyugin
   
  Description: TODO   


  
 */	

#ifndef COMPONENTS_LVGL_ESP32_DRIVERS_LVGL_TFT_HUB75_H_
#define COMPONENTS_LVGL_ESP32_DRIVERS_LVGL_TFT_HUB75_H_

/*********************
 *      INCLUDES
 *********************/
#include <stdbool.h>
#include <stdint.h>

#ifdef LV_LVGL_H_INCLUDE_SIMPLE
#include "lvgl.h"
#else
#include "lvgl/lvgl.h"
#endif
#include "../lvgl_helpers.h"

#define LV_HOR_RES_MAX 64
#define SPI_HOST_MAX 2



int disp_gpio_driver_init();
void hub75_init(void);
void hub75_flush(lv_disp_drv_t *drv, const lv_area_t *area, lv_color_t *color_map);



#endif /* COMPONENTS_LVGL_ESP32_DRIVERS_LVGL_TFT_HUB75_H_ */
